
import React from 'react'
import ReactDOM from 'react-dom/client'
import BibleQuestApp from './BibleQuestApp'
import './style.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BibleQuestApp />
  </React.StrictMode>
)

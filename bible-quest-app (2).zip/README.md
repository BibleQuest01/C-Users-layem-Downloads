
# 📖 Bible Quest: The Lost Scrolls

A fun and educational Bible trivia game for kids — built with React + Vite.

Includes:
- Character & Region selection
- Multiple mini-games (Trivia, Memory, Verse Builder, Image Match, etc.)
- Scroll rewards with sound and animation
- Leaderboard with persistent scores
- Save/Load game state
- Developer tools and Admin reset

---

## 🚀 Quick Start

```bash
npm install
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000)

---

## 📦 Features

- 🎮 6 Mini-Games (Trivia, Sorting, Memory, Verse Builder, Fill-in-the-Blank, Image Match)
- 🏆 Leaderboard with "NEW!" badge and undo
- 📜 Scroll Chest with animated latest scroll
- 💾 Save & Load Game State (JSON)
- ⚙️ Developer Tools panel
- 🔐 Admin Reset (PIN protected)

---

## 🌍 Deployment

### Vercel (Recommended)

1. Push this project to GitHub
2. Go to https://vercel.com
3. Import your repo → Select `bible-quest-app`
4. Done!

### Netlify

1. Push to GitHub
2. Go to https://netlify.com → New site from Git
3. Build Command: `npm run build`
4. Publish directory: `dist`

---

## 🔧 Built With

- [React](https://reactjs.org/)
- [Vite](https://vitejs.dev/)
- [Framer Motion](https://www.framer.com/motion/)

---

## 🙏 Credits

Crafted by Yemi & ChatGPT ❤️  
For Bible learning and fun adventures.
